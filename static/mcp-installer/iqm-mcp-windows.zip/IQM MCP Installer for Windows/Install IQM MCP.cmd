@echo off
echo Starting IQM MCP Installer...
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0required\script.ps1"
if errorlevel 1 (
    echo.
    echo Script execution failed with error code %errorlevel%
    echo.
    pause
    exit /b %errorlevel%
)
pause