# Setup IQM OpenAPI MCP servers for Claude Desktop and/or GitHub Copilot on Windows
# - Uses specifications.json: {"specifications":["url1","url2"]}
# - One MCP server per URL
# - TUI menu with arrow keys + spacebar to select clients

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Info {
    param([string]$Message)
    Write-Host ""
    Write-Host "==> $Message"
}

function Show-ErrorAndPause {
    param([string]$Message)
    Write-Host ""
    Write-Host "ERROR: $Message" -ForegroundColor Red
    Write-Host ""
    [void](Read-Host "Press Enter to close this window...")
    exit 1
}

function Ensure-BrewLike {
    # On Windows we use winget, not brew; this is just naming parity with mac version
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        Show-ErrorAndPause "winget is not available. Please install Node.js and Git manually, then run this script again."
    }
}

function Ensure-Node {
    if (Get-Command node -ErrorAction SilentlyContinue) {
        Write-Info "Node.js found: $(node -v)"
        if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
            Show-ErrorAndPause "npm is missing even though node is present. Please fix your Node installation."
        }
        return
    }

    Write-Info "Node.js not found. Installing with winget (you may be prompted to confirm)..."
    Ensure-BrewLike
    winget install -e --id OpenJS.NodeJS.LTS

    if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
        Show-ErrorAndPause "Node.js still not found after winget install. Please install Node manually and rerun."
    }
    if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
        Show-ErrorAndPause "npm not found after Node install. Please fix your Node installation."
    }
}

function Ensure-Git {
    if (Get-Command git -ErrorAction SilentlyContinue) {
        Write-Info "git found: $(git --version)"
        return
    }

    Write-Info "git not found. Installing with winget..."
    Ensure-BrewLike
    winget install -e --id Git.Git

    if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
        Show-ErrorAndPause "git still not found after winget install. Please install git manually and rerun."
    }
}

function Show-ClientSelectionMenu {
    # Returns hashtables with .Key and .Selected = $true/$false
    $items = @(
        @{ Key = "claude";  Label = "Claude Desktop";                         Selected = $true  },
        @{ Key = "copilot"; Label = "GitHub Copilot (.mcp.json global MCP)";  Selected = $true  }
    )

    $index = 0

    while ($true) {
        Clear-Host
        Write-Host "Select MCP clients to configure:"
        Write-Host ""
        Write-Host "Use ↑ / ↓ to move, Space to toggle, Enter to confirm."
        Write-Host ""

        for ($i = 0; $i -lt $items.Count; $i++) {
            $cursor = if ($i -eq $index) { ">" } else { " " }
            $mark   = if ($items[$i].Selected) { "x" } else { " " }
            Write-Host ("{0} [{1}] {2}" -f $cursor, $mark, $items[$i].Label)
        }

        $keyInfo = [System.Console]::ReadKey($true)
        switch ($keyInfo.Key) {
            'UpArrow'   { $index = ($index - 1 + $items.Count) % $items.Count }
            'DownArrow' { $index = ($index + 1) % $items.Count }
            'Spacebar'  { $items[$index].Selected = -not $items[$index].Selected }
            'Enter' {
                $selected = $items | Where-Object { $_.Selected }
                if ($selected.Count -gt 0) {
                    return $items
                } else {
                    Write-Host ""
                    Write-Host "Please select at least one option. Press any key to continue..."
                    [void][System.Console]::ReadKey($true)
                }
            }
        }
    }
}

function Main {

    Write-Info "Detected OS: $([System.Environment]::OSVersion.Platform)"
    Write-Info "PowerShell version: $($PSVersionTable.PSVersion)"

    $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

    # Ensure core tools
    Ensure-Node
    Ensure-Git

    # TUI menu: which clients to configure
    Write-Info "Opening selection menu..."
    $menuItems = Show-ClientSelectionMenu

    $installClaude  = ($menuItems | Where-Object { $_.Key -eq "claude"  }).Selected
    $installCopilot = ($menuItems | Where-Object { $_.Key -eq "copilot" }).Selected

    if (-not $installClaude -and -not $installCopilot) {
        Write-Info "No clients selected. Exiting."
        return
    }

    # Directories
    $mcpRoot   = Join-Path $env:USERPROFILE "mcp"
    $repoDir   = Join-Path $mcpRoot "openapi-mcp-server"
    $schemaDir = Join-Path $mcpRoot "schemas"
    $baseUrl   = "https://api.iqm.com"

    New-Item -ItemType Directory -Path $mcpRoot   -Force | Out-Null
    New-Item -ItemType Directory -Path $schemaDir -Force | Out-Null

    # Clone or update repo
    if (-not (Test-Path (Join-Path $repoDir ".git"))) {
        Write-Info "Cloning FusionWorks/openapi-mcp-server into $repoDir ..."
        git clone https://github.com/FusionWorks/openapi-mcp-server.git "$repoDir"
    } else {
        Write-Info "Repository already exists at $repoDir. Pulling latest changes..."
        git -C "$repoDir" pull --ff-only 2>$null | Out-Null
    }

    # Install deps & build
    Write-Info "Installing npm dependencies..."
    Push-Location $repoDir
    npm install
    Write-Info "Building the project..."
    npm run build
    Pop-Location

    $indexPath = Join-Path $repoDir "dist\index.js"
    if (-not (Test-Path $indexPath)) {
        Show-ErrorAndPause "Build finished but $indexPath was not found. Check build output."
    }

    # Read specifications.json from script folder
    $specFile = Join-Path $scriptDir "specifications.json"
    if (-not (Test-Path $specFile)) {
        Write-Info "specifications.json not found at $specFile. Creating a template..."
        @'
{
  "specifications": [
    "https://developers.iqm.com/openapi/openapi.json"
  ]
}
'@ | Set-Content -Path $specFile -Encoding UTF8
        Write-Host ""
        Write-Info "A template specifications.json was created at:"
        Write-Host "  $specFile"
        Write-Host "Edit it to add your specification URLs, then run this script again."
        return
    }

    Write-Info "Reading specifications from $specFile ..."
    $jsonRaw = Get-Content -Path $specFile -Raw -Encoding UTF8
    try {
        $specObj = $jsonRaw | ConvertFrom-Json
    } catch {
        Show-ErrorAndPause "Failed to parse specifications.json: $($_.Exception.Message)"
    }

    if (-not $specObj -or -not $specObj.specifications -or
        -not ($specObj.specifications -is [System.Collections.IEnumerable])) {
        Show-ErrorAndPause "specifications.json must look like: {`"specifications`":[`"url1`",`"url2`"]}"
    }

    $urls = @()
    foreach ($u in $specObj.specifications) {
        if ($u -and $u.ToString().Trim()) {
            $urls += $u.ToString().Trim()
        }
    }

    if ($urls.Count -eq 0) {
        Show-ErrorAndPause "No valid URLs found in specifications.specifications array."
    }

    Write-Info "Found the following specification URLs:"
    $urls | ForEach-Object { Write-Host "  - $_" }

    $serverNames = New-Object System.Collections.Generic.List[string]
    $schemaPaths = New-Object System.Collections.Generic.List[string]

    $counter = 1
    foreach ($url in $urls) {
        $filename = [System.IO.Path]::GetFileName($url)
        if ([string]::IsNullOrWhiteSpace($filename)) {
            $filename = "spec$counter.json"
            $counter++
        }
        $specBaseName = [System.IO.Path]::GetFileNameWithoutExtension($filename)
        if ([string]::IsNullOrWhiteSpace($specBaseName)) {
            $specBaseName = "spec$counter"
            $counter++
        }

        $localSpecPath = Join-Path $schemaDir $filename
        Write-Info "Downloading spec '$url' to '$localSpecPath' ..."
        try {
            Invoke-WebRequest -Uri $url -OutFile $localSpecPath -UseBasicParsing
        } catch {
            Show-ErrorAndPause "Failed to download spec from $url : $($_.Exception.Message)"
        }

        if (-not (Test-Path $localSpecPath)) {
            Show-ErrorAndPause "Spec file '$localSpecPath' not found after download."
        }

        $serverName = "iqm-$specBaseName-mcp"
        $serverNames.Add($serverName)
        $schemaPaths.Add($localSpecPath)
        Write-Info "Prepared server '$serverName' for spec '$localSpecPath'"
    }

    # Credentials
    Write-Host ""
    $iqmToken  = Read-Host "Enter your IQM Bearer token (will be stored in config files)"
    $iqmOrgId  = Read-Host "Enter your IQM Organization Account ID (X-IAA-OW-ID)"

    if ([string]::IsNullOrWhiteSpace($iqmToken) -or [string]::IsNullOrWhiteSpace($iqmOrgId)) {
        Show-ErrorAndPause "Both IQM Bearer token and X-IAA-OW-ID are required."
    }

    # Helper: update config via Node (keeps JSON structure consistent)
    function Update-ConfigWithServers {
        param(
            [string]$ConfigPath,
            [bool]  $IsClaudeConfig
        )

        if (-not (Test-Path $ConfigPath)) {
            Write-Info "Config not found; creating new one at:"
            Write-Host "  $ConfigPath"
            '{}' | Set-Content -Path $ConfigPath -Encoding UTF8
        }

        for ($i = 0; $i -lt $serverNames.Count; $i++) {
            $sn = $serverNames[$i]
            $sp = $schemaPaths[$i]

            $env:IQM_TOKEN_ENV   = $iqmToken
            $env:IQM_ORG_ID_ENV  = $iqmOrgId
            $env:SCHEMA_PATH_ENV = $sp
            $env:INDEX_PATH_ENV  = $indexPath
            $env:SERVER_NAME_ENV = $sn
            $env:CONFIG_PATH_ENV = $ConfigPath
            $env:BASE_URL_ENV    = $baseUrl
            $env:IS_CLAUDE_ENV   = if ($IsClaudeConfig) { "1" } else { "0" }

            $nodeScript = @'
const fs = require("fs");
const path = process.env.CONFIG_PATH_ENV;

function readConfig(p) {
  try {
    if (!fs.existsSync(p)) return {};
    const txt = fs.readFileSync(p, "utf8").trim();
    if (!txt) return {};
    return JSON.parse(txt);
  } catch (e) {
    console.error("Failed to read/parse existing config:", e.message);
    process.exit(1);
  }
}

const config = readConfig(path);

if (typeof config !== "object" || config === null) {
  console.error("Existing config is not a JSON object.");
  process.exit(1);
}

const isClaude = process.env.IS_CLAUDE_ENV === "1";

if (isClaude) {
  if (!config.mcpServers || typeof config.mcpServers !== "object") {
    config.mcpServers = {};
  }
} else {
  if (!config.servers || typeof config.servers !== "object") {
    config.servers = {};
  }
}

const serverName = process.env.SERVER_NAME_ENV;
const indexPath = process.env.INDEX_PATH_ENV;
const schemaPath = process.env.SCHEMA_PATH_ENV;
const token = process.env.IQM_TOKEN_ENV;
const orgId = process.env.IQM_ORG_ID_ENV;
const baseUrl = process.env.BASE_URL_ENV || "https://api.iqm.com";

if (!serverName || !indexPath || !schemaPath || !token || !orgId) {
  console.error("Missing required environment variables for MCP config.");
  process.exit(1);
}

const headersObj = {
  Authorization: `Bearer ${token}`,
  "X-IAA-OW-ID": orgId
};
const headersString = JSON.stringify(headersObj);

const serverConfig = {
  command: "node",
  args: [
    indexPath,
    "--schema",
    schemaPath,
    "--base-url",
    baseUrl,
    "--headers",
    headersString
  ]
};

if (isClaude) {
  config.mcpServers[serverName] = serverConfig;
} else {
  config.servers[serverName] = {
    type: "stdio",
    ...serverConfig
  };
}

try {
  fs.writeFileSync(path, JSON.stringify(config, null, 2), "utf8");
  console.log(`Updated ${path} with MCP server '${serverName}'.`);
} catch (e) {
  console.error("Failed to write updated config:", e.message);
  process.exit(1);
}
'@

            node -e $nodeScript
        }
    }

    # Claude Desktop config
    if ($installClaude) {
        $claudeDir    = Join-Path $env:APPDATA "Claude"
        $claudeConfig = Join-Path $claudeDir "claude_desktop_config.json"
        New-Item -ItemType Directory -Path $claudeDir -Force | Out-Null

        Write-Info "Adding MCP servers to Claude config at $claudeConfig ..."
        Update-ConfigWithServers -ConfigPath $claudeConfig -IsClaudeConfig:$true

        # Try to restart Claude Desktop (best-effort)
        Write-Info "Attempting to restart Claude Desktop (best-effort)..."
        $proc = Get-Process -Name "Claude" -ErrorAction SilentlyContinue
        if ($proc) {
            $proc | Stop-Process -Force
            Start-Sleep -Seconds 2
        }

        $started = $false
        $candidateExe = Join-Path $env:LOCALAPPDATA "Programs\Claude\Claude.exe"
        if (Test-Path $candidateExe) {
            Start-Process $candidateExe
            $started = $true
        } else {
            # Try by name
            try {
                Start-Process "Claude" -ErrorAction Stop
                $started = $true
            } catch {
                $started = $false
            }
        }

        if (-not $started) {
            Write-Info "Could not start Claude Desktop automatically. Please start it manually."
        }
    }

    # GitHub Copilot / global MCP config
    if ($installCopilot) {
        $copilotConfig = Join-Path $env:USERPROFILE ".mcp.json"
        Write-Info "Adding MCP servers to global MCP config at $copilotConfig ..."
        Update-ConfigWithServers -ConfigPath $copilotConfig -IsClaudeConfig:$false
    }

    Write-Host ""
    Write-Info "Done!"
    Write-Host "Configured servers:"
    for ($i = 0; $i -lt $serverNames.Count; $i++) {
        Write-Host ("  - {0} (schema: {1})" -f $serverNames[$i], $schemaPaths[$i])
    }

    if ($installClaude) {
        Write-Host "Claude config: $([IO.Path]::Combine($env:APPDATA, 'Claude', 'claude_desktop_config.json'))"
    }
    if ($installCopilot) {
        Write-Host "Global MCP config (for GitHub Copilot / other MCP clients): $env:USERPROFILE\.mcp.json"
    }

    Write-Host ""
    [void](Read-Host "Press Enter to exit...")
}

try {
    Main
} catch {
    Show-ErrorAndPause $_.Exception.Message
}