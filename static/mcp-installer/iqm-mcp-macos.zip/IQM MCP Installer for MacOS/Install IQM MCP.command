#!/bin/bash
# Install IQM OpenAPI MCP servers for Claude Desktop and/or GitHub Copilot
# - Uses specifications.json: {"specifications":["url1","url2"]}
# - One MCP server per URL
# - Offers TUI menu (dialog) to choose: Claude, GitHub Copilot, or both

set -euo pipefail

########################################
# Helpers
########################################

info()  { echo ""; echo "==> $*"; }
error() { echo "ERROR: $*" >&2; }

########################################
# Basic checks & arch detection
########################################

if [ "$(uname)" != "Darwin" ]; then
  error "This script is intended for macOS (Finder .command)."
  exit 1
fi

ARCH="$(uname -m)"  # arm64 (Apple Silicon) or x86_64 (Intel)
info "Detected architecture: $ARCH"

# Script directory (for specifications.json)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Reasonable default potential brew locations to make existing installations available
if [ -d "/opt/homebrew/bin" ]; then
  export PATH="/opt/homebrew/bin:$PATH"
fi
if [ -d "/usr/local/bin" ]; then
  export PATH="/usr/local/bin:$PATH"
fi

########################################
# Homebrew install & PATH persistence
########################################

ensure_brew() {
  if command -v brew >/dev/null 2>&1; then
    info "Homebrew already installed: $(brew --version | head -n1)"
    return 0
  fi

  info "Homebrew not found. Installing Homebrew (may prompt for password & confirmation)..."

  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

  # Determine brew location based on arch
  local BREW_BIN=""
  if [ "$ARCH" = "arm64" ]; then
    BREW_BIN="/opt/homebrew/bin/brew"
  else
    BREW_BIN="/usr/local/bin/brew"
  fi

  if [ ! -x "$BREW_BIN" ]; then
    if ! command -v brew >/dev/null 2>&1; then
      error "Homebrew installation appears to have failed or brew not found."
      exit 1
    fi
    BREW_BIN="$(command -v brew)"
  fi

  # Apply brew environment to this script
  eval "$($BREW_BIN shellenv)"

  # Persist brew PATH for future zsh/bash shells
  add_brew_to_profiles "$BREW_BIN"
}

add_brew_to_profiles() {
  local BREW_BIN="$1"
  local LINE="eval \"\$($BREW_BIN shellenv)\""

  info "Adding Homebrew to PATH for future sessions (zsh & bash)..."

  for profile in "$HOME/.zprofile" "$HOME/.bash_profile"; do
    if [ ! -f "$profile" ]; then
      touch "$profile"
    fi
    if ! grep -Fq "$BREW_BIN shellenv" "$profile"; then
      {
        echo ""
        echo "# Added by IQM MCP setup script to ensure Homebrew is on PATH"
        echo "$LINE"
      } >> "$profile"
      info "Updated $profile"
    else
      info "$profile already contains Homebrew shellenv."
    fi
  done
}

########################################
# Ensure Homebrew + core tools (node, git, dialog)
########################################

ensure_brew

if ! command -v brew >/dev/null 2>&1; then
  error "brew command still not found after installation. Please check your Homebrew install."
  exit 1
fi

info "Ensuring Node.js is installed via Homebrew..."
if ! command -v node >/dev/null 2>&1; then
  brew install node
else
  info "Node.js found: $(node -v)"
fi

if ! command -v npm >/dev/null 2>&1; then
  error "npm not found even though Node is installed. Please fix your Node installation."
  exit 1
fi
if ! command -v npx >/dev/null 2>&1; then
  error "npx not found even though Node is installed. Please fix your Node installation."
  exit 1
fi

info "Ensuring git is installed via Homebrew..."
if ! command -v git >/dev/null 2>&1; then
  brew install git
else
  info "git found: $(git --version)"
fi

info "Ensuring 'dialog' (for TUI menu) is installed via Homebrew..."
if ! command -v dialog >/dev/null 2>&1; then
  brew install dialog
else
  info "dialog found: $(dialog --version 2>/dev/null | head -n1 || echo 'installed')"
fi

########################################
# TUI menu: choose which client(s) to configure
########################################

info "Opening selection menu (use ↑/↓ to move, Space to toggle, Enter to confirm)..."

CHOICES=$(dialog --separate-output --checklist \
  "Select MCP clients to configure:\n\nUse SPACE to check/uncheck, then press ENTER to confirm." \
  16 70 3 \
  "claude"  "Configure Claude Desktop MCP servers"  on \
  "copilot" "Configure GitHub Copilot (.mcp.json global MCP config)" on \
  2>&1 >/dev/tty) || {
    echo ""
    info "Selection cancelled. Exiting."
    exit 0
  }

INSTALL_CLAUDE=false
INSTALL_COPILOT=false

while read -r choice; do
  case "$choice" in
    claude)  INSTALL_CLAUDE=true ;;
    copilot) INSTALL_COPILOT=true ;;
  esac
done <<< "$CHOICES"

if [ "$INSTALL_CLAUDE" = false ] && [ "$INSTALL_COPILOT" = false ]; then
  info "No clients selected. Exiting."
  exit 0
fi

########################################
# Directories and base paths
########################################

MCP_ROOT="$HOME/mcp"
REPO_DIR="$MCP_ROOT/openapi-mcp-server"
SCHEMA_DIR="$MCP_ROOT/schemas"
BASE_URL="https://api.iqm.com"

mkdir -p "$MCP_ROOT" "$SCHEMA_DIR"

########################################
# Clone or update the repo
########################################

if [ ! -d "$REPO_DIR/.git" ]; then
  info "Cloning conor-iqm/openapi-mcp-server into $REPO_DIR ..."
  git clone https://github.com/conor-iqm/openapi-mcp-server.git "$REPO_DIR"
else
  info "Repository already exists at $REPO_DIR. Pulling latest changes..."
  git -C "$REPO_DIR" pull --ff-only || info "Git pull failed; using existing local copy."
fi

########################################
# Install dependencies and build
########################################

info "Installing npm dependencies..."
cd "$REPO_DIR"
npm install

info "Building the project..."
npm run build

INDEX_PATH="$REPO_DIR/dist/index.js"

if [ ! -f "$INDEX_PATH" ]; then
  error "Build finished but $INDEX_PATH not found. Check build output."
  exit 1
fi

########################################
# Discover specifications (remote manifest, local fallback)
########################################

MANIFEST_URL="https://developers.iqm.com/openapi/mcp-manifest.json"
SPEC_FILE="$SCRIPT_DIR/specifications.json"

info "Fetching remote spec manifest from $MANIFEST_URL ..."
MANIFEST_JSON=$(curl -fsSL "$MANIFEST_URL" 2>/dev/null) || MANIFEST_JSON=""

if [ -n "$MANIFEST_JSON" ]; then
  info "Remote manifest fetched successfully."
  URLS=$(node -e '
    let data;
    try {
      data = JSON.parse(process.argv[1]);
    } catch (e) {
      console.error("Failed to parse remote manifest:", e.message);
      process.exit(1);
    }
    if (!data || !Array.isArray(data.specifications)) {
      console.error("Remote manifest must have a \"specifications\" array.");
      process.exit(1);
    }
    for (const url of data.specifications) {
      if (typeof url === "string" && url.trim()) {
        console.log(url.trim());
      }
    }
  ' "$MANIFEST_JSON")
else
  info "Remote manifest unavailable. Falling back to local $SPEC_FILE ..."

  if [ ! -f "$SPEC_FILE" ]; then
    error "No remote manifest and no local specifications.json found."
    error "Please ensure $MANIFEST_URL is reachable, or place a specifications.json next to this script."
    exit 1
  fi

  URLS=$(node -e '
    const fs = require("fs");
    const path = process.argv[1];
    let data;
    try {
      data = JSON.parse(fs.readFileSync(path, "utf8"));
    } catch (e) {
      console.error("Failed to parse specifications.json:", e.message);
      process.exit(1);
    }
    if (!data || !Array.isArray(data.specifications)) {
      console.error("specifications.json must look like: {\"specifications\":[\"url1\",\"url2\"]}");
      process.exit(1);
    }
    for (const url of data.specifications) {
      if (typeof url === "string" && url.trim()) {
        console.log(url.trim());
      }
    }
  ' "$SPEC_FILE")
fi

if [ -z "$URLS" ]; then
  error "No valid specification URLs found."
  exit 1
fi

info "Found the following specification URLs:"
echo "$URLS" | sed 's/^/  - /'

declare -a SERVER_NAMES=()
declare -a SCHEMA_PATHS=()

while IFS= read -r URL; do
  [ -z "$URL" ] && continue
  FILENAME="$(basename "$URL")"
  # spec name = filename without extension (e.g. openapi from openapi.json)
  SPEC_BASENAME="${FILENAME%%.*}"
  [ -z "$SPEC_BASENAME" ] && SPEC_BASENAME="spec"

  LOCAL_SPEC_PATH="$SCHEMA_DIR/$FILENAME"

  info "Downloading spec '$URL' to '$LOCAL_SPEC_PATH' ..."
  curl -L "$URL" -o "$LOCAL_SPEC_PATH"

  if [ ! -f "$LOCAL_SPEC_PATH" ]; then
    error "Failed to download spec from $URL"
    exit 1
  fi

  SERVER_NAME="iqm-${SPEC_BASENAME}-mcp"
  SERVER_NAMES+=("$SERVER_NAME")
  SCHEMA_PATHS+=("$LOCAL_SPEC_PATH")

  info "Prepared server '$SERVER_NAME' for spec '$LOCAL_SPEC_PATH'"
done <<< "$URLS"

########################################
# Ask user for IQM credentials (used for all servers)
########################################

echo ""
read -r -p "Enter your IQM Bearer token (will be stored in config files): " IQM_TOKEN </dev/tty
read -r -p "Enter your IQM Organization Account ID (X-IAA-OW-ID): " IQM_ORG_ID </dev/tty

if [ -z "${IQM_TOKEN}" ] || [ -z "${IQM_ORG_ID}" ]; then
  error "Both IQM Bearer token and X-IAA-OW-ID are required."
  exit 1
fi

info "Credentials captured successfully (token length: ${#IQM_TOKEN}, org ID: ${IQM_ORG_ID})"

########################################
# Configure Claude Desktop (if selected)
########################################

if [ "$INSTALL_CLAUDE" = true ]; then
  CLAUDE_DIR="$HOME/Library/Application Support/Claude"
  CLAUDE_CONFIG="$CLAUDE_DIR/claude_desktop_config.json"

  mkdir -p "$CLAUDE_DIR"

  # Quit Claude BEFORE writing config so it doesn't overwrite changes on exit
  if pgrep -x "Claude" >/dev/null 2>&1; then
    info "Claude is running; asking it to quit before updating config..."
    osascript -e 'tell application "Claude" to quit' >/dev/null 2>&1 || true
    sleep 2
  fi

  if [ ! -f "$CLAUDE_CONFIG" ]; then
    info "Claude config not found; creating new one at:"
    echo "  $CLAUDE_CONFIG"
    echo '{}' > "$CLAUDE_CONFIG"
  fi

  info "Adding MCP servers to Claude config at $CLAUDE_CONFIG ..."

  for i in "${!SERVER_NAMES[@]}"; do
    SN="${SERVER_NAMES[$i]}"
    SP="${SCHEMA_PATHS[$i]}"

    IQM_TOKEN_ENV="$IQM_TOKEN" \
    IQM_ORG_ID_ENV="$IQM_ORG_ID" \
    SCHEMA_PATH_ENV="$SP" \
    INDEX_PATH_ENV="$INDEX_PATH" \
    SERVER_NAME_ENV="$SN" \
    CONFIG_PATH_ENV="$CLAUDE_CONFIG" \
    BASE_URL_ENV="$BASE_URL" \
    node << 'EOF'
const fs = require('fs');
const path = process.env.CONFIG_PATH_ENV;

function readConfig(p) {
  try {
    if (!fs.existsSync(p)) return {};
    const txt = fs.readFileSync(p, 'utf8').trim();
    if (!txt) return {};
    return JSON.parse(txt);
  } catch (e) {
    console.error("Failed to read/parse existing Claude config:", e.message);
    process.exit(1);
  }
}

const config = readConfig(path);

if (typeof config !== 'object' || config === null) {
  console.error("Existing Claude config is not a JSON object.");
  process.exit(1);
}

if (!config.mcpServers || typeof config.mcpServers !== 'object') {
  config.mcpServers = {};
}

const serverName = process.env.SERVER_NAME_ENV;
const indexPath = process.env.INDEX_PATH_ENV;
const schemaPath = process.env.SCHEMA_PATH_ENV;
const token = process.env.IQM_TOKEN_ENV;
const orgId = process.env.IQM_ORG_ID_ENV;
const baseUrl = process.env.BASE_URL_ENV || "https://api.iqm.com";

if (!serverName || !indexPath || !schemaPath || !token || !orgId) {
  console.error("Missing required environment variables for MCP config.");
  process.exit(1);
}

const headersObj = {
  Authorization: `Bearer ${token}`,
  "X-IAA-OW-ID": orgId
};
const headersString = JSON.stringify(headersObj);

config.mcpServers[serverName] = {
  command: "node",
  args: [
    indexPath,
    "--schema",
    schemaPath,
    "--base-url",
    baseUrl,
    "--headers",
    headersString
  ]
};

try {
  fs.writeFileSync(path, JSON.stringify(config, null, 2), 'utf8');
  console.log(`Updated Claude config with MCP server '${serverName}'.`);
} catch (e) {
  console.error("Failed to write updated Claude config:", e.message);
  process.exit(1);
}
EOF

  done
fi

########################################
# Configure GitHub Copilot global MCP config (~/.mcp.json) if selected
########################################

if [ "$INSTALL_COPILOT" = true ]; then
  COPILOT_MCP_CONFIG="$HOME/.mcp.json"

  if [ ! -f "$COPILOT_MCP_CONFIG" ]; then
    info "Global MCP config for Copilot/Visual Studio not found; creating:"
    echo "  $COPILOT_MCP_CONFIG"
    echo '{}' > "$COPILOT_MCP_CONFIG"
  fi

  info "Adding MCP servers to $COPILOT_MCP_CONFIG ..."

  for i in "${!SERVER_NAMES[@]}"; do
    SN="${SERVER_NAMES[$i]}"
    SP="${SCHEMA_PATHS[$i]}"

    IQM_TOKEN_ENV="$IQM_TOKEN" \
    IQM_ORG_ID_ENV="$IQM_ORG_ID" \
    SCHEMA_PATH_ENV="$SP" \
    INDEX_PATH_ENV="$INDEX_PATH" \
    SERVER_NAME_ENV="$SN" \
    CONFIG_PATH_ENV="$COPILOT_MCP_CONFIG" \
    BASE_URL_ENV="$BASE_URL" \
    node << 'EOF'
const fs = require('fs');
const path = process.env.CONFIG_PATH_ENV;

function readConfig(p) {
  try {
    if (!fs.existsSync(p)) return {};
    const txt = fs.readFileSync(p, 'utf8').trim();
    if (!txt) return {};
    return JSON.parse(txt);
  } catch (e) {
    console.error("Failed to read/parse existing MCP config:", e.message);
    process.exit(1);
  }
}

const config = readConfig(path);

if (typeof config !== 'object' || config === null) {
  console.error("Existing MCP config is not a JSON object.");
  process.exit(1);
}

if (!config.servers || typeof config.servers !== 'object') {
  config.servers = {};
}

const serverName = process.env.SERVER_NAME_ENV;
const indexPath = process.env.INDEX_PATH_ENV;
const schemaPath = process.env.SCHEMA_PATH_ENV;
const token = process.env.IQM_TOKEN_ENV;
const orgId = process.env.IQM_ORG_ID_ENV;
const baseUrl = process.env.BASE_URL_ENV || "https://api.iqm.com";

if (!serverName || !indexPath || !schemaPath || !token || !orgId) {
  console.error("Missing required environment variables for MCP config.");
  process.exit(1);
}

const headersObj = {
  Authorization: `Bearer ${token}`,
  "X-IAA-OW-ID": orgId
};
const headersString = JSON.stringify(headersObj);

config.servers[serverName] = {
  type: "stdio",
  command: "node",
  args: [
    indexPath,
    "--schema",
    schemaPath,
    "--base-url",
    baseUrl,
    "--headers",
    headersString
  ]
};

try {
  fs.writeFileSync(path, JSON.stringify(config, null, 2), 'utf8');
  console.log(`Updated ~/.mcp.json with MCP server '${serverName}'.`);
} catch (e) {
  console.error("Failed to write updated MCP config:", e.message);
  process.exit(1);
}
EOF

  done
fi

########################################
# Restart/start Claude Desktop (only if we touched Claude)
########################################

if [ "$INSTALL_CLAUDE" = true ]; then
  info "Starting Claude Desktop (if installed)..."
  if ! open -a "Claude" >/dev/null 2>&1; then
    info "Could not start Claude Desktop automatically. Please open it manually."
  fi
fi

########################################
# Open VS Code for Copilot users
########################################

if [ "$INSTALL_COPILOT" = true ]; then
  echo ""
  info "GitHub Copilot MCP configuration complete!"
  info "Restarting VS Code to load MCP servers..."
  
  # Quit VS Code if it's running
  if pgrep -x "Code" >/dev/null 2>&1 || pgrep -x "Visual Studio Code" >/dev/null 2>&1; then
    info "Closing VS Code..."
    osascript -e 'quit app "Visual Studio Code"' >/dev/null 2>&1 || true
    sleep 2
  fi
  
  # Start VS Code in a new window with Copilot chat
  if command -v code >/dev/null 2>&1; then
    info "Starting VS Code with GitHub Copilot chat..."
    code --new-window &
    sleep 3
    code --command workbench.panel.chat.view.copilot.focus
    code --command workbench.action.chat.open
  else
    info "VS Code 'code' command not found. Opening VS Code application..."
    if open -a "Visual Studio Code" >/dev/null 2>&1; then
      info "VS Code opened. Please open GitHub Copilot chat to access MCP tools."
    else
      info "Could not open VS Code automatically. Please open it manually and access GitHub Copilot chat."
    fi
  fi
fi

echo ""
info "Done!"
echo "Configured servers:"
for i in "${!SERVER_NAMES[@]}"; do
  echo "  - ${SERVER_NAMES[$i]} (schema: ${SCHEMA_PATHS[$i]})"
done

if [ "$INSTALL_CLAUDE" = true ]; then
  echo "Claude config: $HOME/Library/Application Support/Claude/claude_desktop_config.json"
fi
if [ "$INSTALL_COPILOT" = true ]; then
  echo "Global MCP config (for GitHub Copilot / Visual Studio): $HOME/.mcp.json"
fi

echo ""
info "Menu navigation tip: when you run this script again,"
echo "  ↑/↓ to move, Space to toggle checkboxes, Enter to confirm."